
package registroproyectos;


public abstract class Proyecto {
   
    private String nombre;
    private String equipoResponsable;
    private EstadoProyecto estadoActual;

    public Proyecto(String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        this.nombre = nombre;
        this.equipoResponsable = equipoResponsable;
        this.estadoActual = estadoActual;
    }
       public String getNombre() {
        return nombre;
    }

    public String getEquipoResponsable() {
        return equipoResponsable;
    }

    public EstadoProyecto getEstadoActual() {
        return estadoActual;
   }
    public boolean existeProyecto (Proyecto proyecto){
        if (this.getNombre().equals(proyecto.getNombre()) && this.getEquipoResponsable().equals(proyecto.getEquipoResponsable())){
            return true;
        }
        return false;
    }
    @Override
    public String toString(){
        StringBuilder sb= new StringBuilder();
        sb.append ("Nombre proyecto: " + this.getNombre() + " ");
        sb.append ("Estado actual: " + this.getEstadoActual() + " ");
        sb.append ("Atributo del proyecto " + this.getEquipoResponsable() + " ");
        return(sb.toString());
    }
  
}
