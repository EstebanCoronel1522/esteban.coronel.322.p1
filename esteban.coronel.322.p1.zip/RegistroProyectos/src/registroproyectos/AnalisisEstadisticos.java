
package registroproyectos;

public class AnalisisEstadisticos extends Proyecto implements Actualizable {

   
    private TipoAnalisis tipoAnalisis;
    public AnalisisEstadisticos(TipoAnalisis tipoAnalisis, String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        super(nombre, equipoResponsable, estadoActual);
        this.tipoAnalisis = tipoAnalisis;
    }
    
    
     public TipoAnalisis getTipoAnalisis() {
        return tipoAnalisis;
    }
    @Override
    public void actualizarResultados(){
        System.out.println("El proyecto" + getNombre()+ this.getNombre() + " fue actualizado" );
    }
     @Override
    public String toString(){
    StringBuilder sb= new StringBuilder();
    sb.append ("Nombre proyecto: " + this.getNombre() + " ");
    sb.append ("Estado actual: " + this.getEstadoActual() + " ");
    sb.append ("Atributo del proyecto " + this.getEquipoResponsable() + " ");
    sb.append ("Tipo de analisis: " + this.getTipoAnalisis() + " ");
    return(sb.toString());
    }
  
}
