
package registroproyectos;

import java.util.ArrayList;


public class Laboratorio {
    private ArrayList<Proyecto> listaProyecto = new ArrayList<>();
    
    public void agregarProyecto(Proyecto proyecto)throws DatoLaboratorioExistente{
        if (verificarProyecto(proyecto)){
        throw new DatoLaboratorioExistente ("Ya existe este proyecto" + proyecto.getNombre()
                    + " en el laboratorio " + proyecto.getEquipoResponsable());
        }
        listaProyecto.add(proyecto);
        System.out.println("Proyecto " + proyecto.getNombre() + "agregado") ;
    }
    public void mostrarProyectos(){
        for (Proyecto proyecto : listaProyecto){
            System.out.println(proyecto.toString());
    }
        
  }
    
    public void actualizarResultadosProyectos(){
        for (Proyecto proyecto: listaProyecto){
            if( proyecto instanceof SistemasDeVisualizacion){
                System.out.println("Visualizacion no puede actualizarse directamente");
                continue;
            }
            
           ((Actualizable)proyecto).actualizarResultados();
        }
    }
    public ArrayList<Proyecto>actualizarEstadoProyectos(EstadoProyecto nuevoEstado){
        
        ArrayList<Proyecto> listaActualizada = new ArrayList<>();
        for(Proyecto proyecto: listaProyecto){
            if (nuevoEstado == null) {
            System.out.println("No se realizó ninguna modificación (el estado indicado es nulo).");
          } 
            if(proyecto.getEstadoActual().equals(nuevoEstado)){
                listaActualizada.add(proyecto);
                System.out.println(proyecto.toString());
            }
        }      
        return listaActualizada;
  }
    public boolean verificarProyecto (Proyecto nuevoProyecto){
        for (Proyecto proyecto: listaProyecto){
            if (proyecto.existeProyecto(nuevoProyecto)){
                return true;
            }
        }
        return false;
    }
}
