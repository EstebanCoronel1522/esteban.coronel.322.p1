
package registroproyectos;


public class RegistroProyectos {

    
    public static void main(String[] args) throws DatoLaboratorioExistente {
       
        Laboratorio sistema = new Laboratorio();

        System.out.println("---Agregando Proyectos---");
        sistema.agregarProyecto( new MachineLearning( 8.5,"Predicción de Ventas", "DataScienceTeam", EstadoProyecto.EN_DESARROLLO));
        sistema.agregarProyecto( new MachineLearning( 8.5,"Predicción de Ventas", "DataScienceTeam", EstadoProyecto.EN_DESARROLLO));
        sistema.agregarProyecto( new MachineLearning( 90.5,"Predicción de Ventas", "QATeam", EstadoProyecto.ENTRENANDO_MODELO));
        sistema.agregarProyecto(new AnalisisEstadisticos(TipoAnalisis.PREDICTIVO, "Análisis de Comportamiento de Usuarios", "DataLab-B", EstadoProyecto.EN_DESARROLLO));
        sistema.agregarProyecto(new AnalisisEstadisticos(TipoAnalisis.INFERENCIAL, "Análisis de Comportamiento de Usuarios", "DataLab-B", EstadoProyecto.FINALIZADO));
        sistema.agregarProyecto(new SistemasDeVisualizacion(6 ,"Visualización de Datos de Tráfico", "DataVisTeam", EstadoProyecto.FINALIZADO));

       
        
        sistema.mostrarProyectos();

       
        sistema.actualizarResultadosProyectos();

        
        sistema.actualizarEstadoProyectos(EstadoProyecto.FINALIZADO);
        
        
        sistema.mostrarProyectos();
    }
}

    
    
