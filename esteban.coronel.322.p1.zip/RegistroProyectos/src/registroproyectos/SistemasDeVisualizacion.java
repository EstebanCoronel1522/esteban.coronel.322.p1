package registroproyectos;

public class SistemasDeVisualizacion extends Proyecto{
   
    private int cantidadGraficosGenerados;
    public SistemasDeVisualizacion(int cantidadGraficosGenerados, String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
        super(nombre, equipoResponsable, estadoActual);
        this.cantidadGraficosGenerados = cantidadGraficosGenerados;
    }
    
    
      public int getCantidadGraficosGenerados() {
        return cantidadGraficosGenerados;
      }
       @Override
    public String toString(){
        StringBuilder sb= new StringBuilder();
        sb.append ("Nombre proyecto: " + this.getNombre() + " ");
        sb.append ("Estado actual: " + this.getEstadoActual() + " ");
        sb.append ("Atributo del proyecto " + this.getEquipoResponsable() + " ");
        sb.append ("Cantidad de graficos generados: " + this.getCantidadGraficosGenerados() + " ");
        return(sb.toString());
    }
  
}
