
package registroproyectos;


public interface Actualizable {
    void actualizarResultados();
}
