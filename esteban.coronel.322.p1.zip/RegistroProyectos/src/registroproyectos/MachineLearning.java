package registroproyectos;

public class MachineLearning extends Proyecto implements Actualizable {

           private double porcentajePrecisionAlcanzado;
           private static final double PORC_MAX = 100;
           private static final double PORC_MIN = 0;
           public MachineLearning(double porcentajePrecisionAlcanzado, String nombre, String equipoResponsable, EstadoProyecto estadoActual) {
           super(nombre, equipoResponsable, estadoActual);
           this.porcentajePrecisionAlcanzado = porcentajePrecisionAlcanzado;
    }        
        public double getPorcentajePrecisionAlcanzado() {
            return porcentajePrecisionAlcanzado;
        }

        @Override
        public void actualizarResultados(){
            System.out.println("El proyecto " + this.getNombre() + "fue actualizado ");
}

        
        @Override
        public String toString(){
        StringBuilder sb= new StringBuilder();
        sb.append ("Nombre proyecto: " + this.getNombre() + " ");
        sb.append ("Estado actual: " + this.getEstadoActual() + " ");
        sb.append ("Atributo del proyecto " + this.getEquipoResponsable() + " ");
        sb.append ("Porcentaje de precision alcanzado" + this.getPorcentajePrecisionAlcanzado() + "% ");
        return(sb.toString());
    }
  
  
}
        


